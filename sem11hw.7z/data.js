const dataFeaturedItems = `
[
{
"name" : "ELLERY X M'O CAPSULE",
"description" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
"price" : "52.00",
"url" : "https://i.pinimg.com/originals/89/69/c0/8969c08da7e92591dc33e4490f6d4353.jpg"
},
{
"name" : "ELLERY X M'O CAPSULE",
"description" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
"price" : "52.00",
"url" : "https://s22221.cdn.ngenix.net/media/catalog/product/C/O/CONT-7139_foto_6715.jpg"
},
{
"name" : "ELLERY X M'O CAPSULE",
"description" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
"price" : "52.00",
"url" : "https://i.pinimg.com/originals/68/f3/1d/68f31de0ce5200c4a5859eaf87a55620.jpg"
},
{
"name" : "ELLERY X M'O CAPSULE",
"description" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
"price" : "52.00",
"url" : "https://crobux.ru/wp-content/uploads/8/7/0/870e67fc9d633ca3373dbd55a3cf6d30.jpeg"
},
{
"name" : "ELLERY X M'O CAPSULE",
"description" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
"price" : "52.00",
"url" : "https://ak-bravo.ee/image/cache/catalog/journal3/products/fashion/l1-1000x1000.jpg"
},
{
"name" : "ELLERY X M'O CAPSULE",
"description" : "Known for her sculptural takes on traditional tailoring, Australian arbiter of cool Kym Ellery teams up with Moda Operandi.",
"price" : "52.00",
"url" : "https://authentictheme.com/apparent/wp-content/uploads/sites/36/2017/10/authentic-demo-image-00011.jpg"
}
]
`